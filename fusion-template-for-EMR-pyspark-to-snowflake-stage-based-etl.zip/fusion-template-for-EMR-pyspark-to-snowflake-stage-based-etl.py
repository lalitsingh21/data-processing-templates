import subprocess
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from dateutil import parser
from os import getcwd, mkdir, remove
from os.path import isdir, isfile
from json import load
from pyspark.sql.functions import *
from pyspark.sql import Window
import time
from dataprocessing import DataProcessingIMPB
from snsmessage import message
from logger import logger
import sys

class ExtractTransformLoad:

    def __init__(self, bucket, snsarn, region, environment):
        """
        > Spark Session and configurations are loaded here
        """
        self.session = SparkSession\
            .builder \
            .enableHiveSupport() \
            .appName(self.__class__.__name__) \
            .getOrCreate()

        self.snsarn = snsarn
        self.bucket = bucket
        self.region = region
        self.environment = environment

        try:
            logger("I", "Reading the DDL's from Config file")
            
            if self.environment == 'dev' or self.environment == 'uat':
                ddl_file = "ddl_dev.json"
            elif self.environment=='prod':
                ddl_file = "ddl_prd.json"

            with open(f"/home/hadoop/scripts/config/{ddl_file}", "r") as hiveTables:
                hiveTables = load(hiveTables)
                self.table_list = hiveTables['tables']
                self.table_configs = hiveTables['tablesConfig']

        except Exception as e:
            logger(
                "E", "Caught exception {} ,  while reading the ddl.json file".format(e))
            message("E", "Unable to Read Config File",
                    e, self.region, self.snsarn)

    def createHiveTables(self):
        """
        1. Run a loop through all the tables in the list.
        2. S3 location is where the snowflake stages will be pointing to.
        """

        def ddl_partitioned(tableName, tableSchema, partitionColumns, 
                            delimiter, s3Location, tblProperties):

            try:

                self.session.sql("create external table if not exists {}\
                                ({}) \
                                partitioned by ({})\
                                row format delimited \
                                fields terminated by '{}' \
                                location '{}' \
                                tblproperties({})".format(tableName,
                                                          tableSchema,
                                                          partitionColumns,
                                                          delimiter,
                                                          s3Location,
                                                          tblProperties))

                self.session.sql('msck repair table {}'.format(tableName))
                logger("I", "Created table {}".format(tableName))

            except Exception as e:
                logger("E", "Caught exception {} , while creating the table for {}".format(
                    e, tableName))
                message("E", "Unable to Create table",
                        e, self.region, self.snsarn)

        def ddl_non_partitioned(tableName, tableSchema, delimiter, 
                                s3Location, tblProperties):

            try:

                self.session.sql("create external table if not exists {}\
                                ({}) \
                                row format delimited \
                                fields terminated by '{}' \
                                location '{}' \
                                tblproperties({})".format(tableName,
                                                          tableSchema,
                                                          delimiter,
                                                          s3Location,
                                                          tblProperties))

                logger("I", "Created table {}".format(tableName))

            except Exception as e:
                logger("E", "Caught exception {} , while creating the table for {}".format(
                    e, tableName))
                message("E", "Unable to Create table",
                        e, self.region, self.snsarn)

        for tableName in self.table_list:
            tableSchema = self.table_configs[tableName]["schema"]
            isPartitioned = self.table_configs[tableName]["isPartitioned"]
            partitionedColumns = self.table_configs[tableName]["partitionColumns"]
            delimiter = self.table_configs[tableName]["delimiter"]
            tblProperties = self.table_configs[tableName]["tblProperties"]
            isDerivedTable = self.table_configs[tableName]["derivedTable"]

            if isDerivedTable:
                s3Location = "s3://{}/{}".format(self.bucket,
                                                 self.table_configs[tableName]["s3Location"])
            else:
                s3Location = self.table_configs[tableName]["s3Location"]

            if isPartitioned:
                ddl_partitioned(tableName, tableSchema,
                                partitionedColumns, delimiter, s3Location, tblProperties)
            else:
                ddl_non_partitioned(tableName, tableSchema,
                                    delimiter, s3Location, tblProperties)

    def preRunCheck(self, stopDate):
        """This will check if there is latest date's partition is there,
         in USPS table or not."""
        max_filedate = self.session\
            .sql('select max(filedate) from ebt_usps_response') \
            .collect()
        
        if str(max_filedate[0][0])==stopDate:
            logger("I", f'Partition exists for {stopDate} in USPS Response')
            pass
        else:
            error_message = "ERROR : The latest data is not there in the USPS Response table"
            logger("E", f'No partition exists for {stopDate} in USPS Response')
            message("E", error_message,error_message,
                    self.region, self.snsarn)
            sys.exit()


    def postRunCheck(self, stopDate):
        """This will check if there is latest date's partition is there, 
        in final flat table or not."""
        max_filedate = self.session\
            .sql('select max(firstoccdate) from impb_label_flat') \
            .collect()

        if str(max_filedate[0][0]) == stopDate:
            success_message = f"IMPB ETL till {stopDate} success!"
            message("I", success_message , success_message,
                    self.region, self.snsarn)
        else:
            error_message = "ERROR : The ETL failed! Check logs."
            logger("E", f'ETL failed as {stopDate} partition not in flat data.')
            message("E", error_message, error_message,
                    self.region, self.snsarn)

    
    def extraction(self, startDate, stopDate, tableName):
        """
        tableName ::
        > "tracking" : USPS Response table
        > "manifest" : GCS Real-time table
        """
        def get_tracking(startDate, stopDate):

            try:
                startDate = (parser.parse(startDate) - timedelta(days=30)).strftime('%Y%m%d')
                stopDate = (parser.parse(stopDate)).strftime('%Y%m%d')

                raw_data = self.session\
                    .sql('select * from ebt_usps_response \
                        where filedate >= {} and filedate <= {}'.format(startDate, stopDate))

                return raw_data\
                    .withColumn('eventdate', from_unixtime(unix_timestamp(col('eventdate'), 'yyyyMMdd'), 'yyyy-MM-dd'))\
                    .withColumn('eventtime', from_unixtime(unix_timestamp(col('eventtime'), 'HHmmssSSS'), 'HH:mm:ss'))\
                    .withColumn('createdate', from_unixtime(unix_timestamp(col('createdate'), 'yyyy-MM-dd HH:mm:ss.SSS'),
                                                            'yyyy-MM-dd   HH:mm:ss'))\
                    .withColumn('updatedate', from_unixtime(unix_timestamp(col('updatedate'), 'yyyy-MM-dd HH:mm:ss.SSS'), 'yyyy-MM-dd HH:mm:ss'))

            except Exception as e:
                logger("E", "Caught Exception while getting the Tracking data")
                message("E", "Unable to load tracking data",
                        e, self.region, self.snsarn)

        def get_manifest(startDate, stopDate):
            pass

        def get_flat(startDate, stopDate):
            try:
                return self.session\
                    .sql('select * from impb_label_flat \
                        where FirstOccDate >= {} and FirstOccDate <= {}'.format(startDate, stopDate))

            except Exception as e:
                logger("E", "Caught Exception while getting the Flat data.")
                message("E", "Unable to load flat data",
                        e, self.region, self.snsarn)

        if tableName == "tracking":
            logger("I", "Loading Tracking data.")
            return get_tracking(startDate, stopDate)
        elif tableName == "flat":
            logger("I", "Loading Flat data.")
            return get_flat(startDate, stopDate)
        else:
            pass

    def extract_dimension_table(self, tableName):
        """
        tableName ::
        > "calendar" : dimdate
        > "zone" : USPS Zone
        > "sla" : USPS SLA table
        > "exception" : USPS Exception table
        """
        try:

            if tableName == "calendar":
                return self.session.sql('select * from dimdate')
            elif tableName == "zone":
                logger("I", "Loading the Zone data.")
                return self.session.sql('select * from usps_zone')
            elif tableName == "sla":
                logger("I", "Loading the ServiceStd(SLA) data.")
                return self.session.sql('select * from usps_servicestd')
            elif tableName == "exception":
                logger("I", "Loading the Exception data.")
                return self.session.sql('select * from usps_pm_exception')
            else:
                pass

        except Exception as e:
            logger(
                "E", "Caught Exception {} ,  while Extracting the dimension table".format(e))
            message("E", "Unable to extract Dimension table",
                    e, self.region, self.snsarn)

    def transformation(self, startDate, stopDate):
        """
        1. Extract all the dependent tables
        2. Get the flat table
        """
        try:
            tracking_data_raw = self.extraction(
                startDate, stopDate, "tracking")
            old_flat_data = self.extraction(startDate, stopDate, "flat")
            # manifest_data_raw = self.extraction(startDate, stopDate, "manifest")
            zone_dimension = self.extract_dimension_table("zone")
            sla_dimension = self.extract_dimension_table("sla")
            exception_dimension = self.extract_dimension_table("exception")
            
            logger("I", "Loading the Calender data.")
            
            startCalendar5wd = self.extract_dimension_table("calendar")
            stopCalendar5wd = self.extract_dimension_table("calendar")
            startCalendar6wd = self.extract_dimension_table("calendar")
            stopCalendar6wd = self.extract_dimension_table("calendar")
            startCalendar7wd = self.extract_dimension_table("calendar")
            stopCalendar7wd = self.extract_dimension_table("calendar")

            # Get the data that is already delivered
            logger("I", "Getting the delivered parcel data info.")
            delivered_flat = old_flat_data\
                .filter((col('DeliveryEventcode').isNull() == False))\
                .drop(col('firstoccdate'))

            logger("I", "Persisting the delivered data on HDFS.")
            delivered_flat.createOrReplaceTempView('delivered_flat_v')

            self.\
                session.\
                sql('create table delivered_flat_hdfs as select * from delivered_flat_v')

            delivered_flat_hdfs_df = self.\
                session.sql('select * from delivered_flat_hdfs')

            logger("I", "Persisted the delivered data on HDFS.")

            delivered_distinct = delivered_flat_hdfs_df\
                .select('packageidentifier')\
                .distinct()

            # Get the data that is undelivered
            logger("I", "Getting the un-delivered parcel data info.")
            undelivered_distinct = old_flat_data\
                .filter(col('DeliveryEventcode').isNull())\
                .select('packageidentifier')\
                .distinct()

            used_parcels = delivered_distinct\
                .union(undelivered_distinct)  # Distinct of old_flat_data will also do same

            undelivered_tracking_raw = tracking_data_raw\
                .join(undelivered_distinct,
                      undelivered_distinct.packageidentifier == tracking_data_raw.externaltrackingid, "inner")\
                .select(tracking_data_raw['*'])

            # Get the data that is new
            logger("I", "Getting the new parcel data info.")
            new_tracking_raw = tracking_data_raw\
                .filter(col('filedate') == stopDate)\
                .join(used_parcels,
                      used_parcels.packageidentifier == tracking_data_raw.externaltrackingid, "left_anti")\
                .select(tracking_data_raw['*'])

            # Union the tracking data that is new and pass it on the get_flat_table
            logger("I", "Combining the new parcel data with tracking data. ")
            tracking_data_new = undelivered_tracking_raw.union(
                new_tracking_raw)
            tracking_data_new.createOrReplaceTempView('tracking_data_raw_v')
            self.session.sql('drop table if exists tracking_data_hdfs')
            self.session.sql(
                'create table tracking_data_hdfs as select * from tracking_data_raw_v')
            tracking_data_new_hdfs = self\
                .session.sql('select * from tracking_data_hdfs')
            dataprocessing = DataProcessingIMPB()
            logger("I", "Getting Flat data after Data Processing.")
            flat_new = dataprocessing\
                .get_flat_table(tracking_data_new_hdfs,
                                zone_dimension,
                                sla_dimension,
                                exception_dimension,
                                startCalendar5wd,
                                stopCalendar5wd,
                                startCalendar6wd,
                                stopCalendar6wd,
                                startCalendar7wd,
                                stopCalendar7wd)

            flat_new.createOrReplaceTempView('flat_new_v')
            
            logger("I", "Persisting the new flat data on HDFS.")

            self.\
                session.\
                sql('create table flat_new_hdfs as select * from flat_new_v')

            flat_new_hdfs_df = self\
                .session\
                .sql('select * from flat_new_hdfs')
            
            logger("I", "Persisted the new flat data on HDFS.")

            # Union the output with already delivered data

            return flat_new_hdfs_df.union(delivered_flat_hdfs_df)

        except Exception as e:
            logger("E", "Caught Exception {} , while Transforming the data ".format(e))
            message("E", "Unable to Tranform data",
                    e, self.region, self.snsarn)

    def load(self, startDate, stopDate):

        try:
            
            self.preRunCheck(stopDate)
            logger("I", f"Loading the data for dates {startDate} to {stopDate}.")
            flat_data = self.transformation(startDate, stopDate)
            flat_data = flat_data\
                .withColumn('first_occ_date', \
                from_unixtime(unix_timestamp(col('firsteventdate'), 'yyyy-MM-dd'), 'yyyyMMdd'))
            flat_data.createOrReplaceTempView('flat_view')
            self.session.sql('drop table if exists flat_data')
            self.session.sql(
                'create table flat_data as select * from flat_view')

            logger("I", "Calling the Hive script for snowflake refresh.")
            subprocess.call(["sh", "hiveLoad.sh", startDate,
                             stopDate, self.bucket], cwd='/home/hadoop/scripts/shell')
            
            self.postRunCheck(stopDate)

        except Exception as e:
            logger("E", "Caught Exception {} , while Loading the data ".format(e))
            message("E", "Unable to load data",
                    e, self.region, self.snsarn)
