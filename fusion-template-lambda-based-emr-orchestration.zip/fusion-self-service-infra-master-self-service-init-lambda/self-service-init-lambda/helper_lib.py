import configparser
import boto3
import logging
import logging.config
from aws_logging_handlers.S3 import S3Handler
import os
import atexit

#init looging and configure

logger=''
def init_logging(logfile):  
    try: 
        global logger    
        log_bucket = os.environ['log_bucket']
        log_bucket_prefix = os.environ['log_bucket_prefix']
        log_folder = os.environ['log_bucket_outputfolder']
        
        s3_handler = S3Handler(log_bucket_prefix+"/"+log_folder+"/"+logfile, log_bucket)
        formatter = logging.Formatter('[%(asctime)s] %(filename)s:%(lineno)d} %(levelname)s - %(message)s')
        s3_handler.setFormatter(formatter)
        logger = logging.getLogger(logfile)
        logger.setLevel(logging.INFO)
        logger.addHandler(s3_handler)
        logger.info("Logging initiated !")
        try:
            atexit.register(log_close)    
        except Exception as e:    
            print("Could not call log write function " + str(e))
    except Exception as e:
        print("Logging could not be initiated! : " + str(e))
        raise Exception("Logging could not be initiated! : " + str(e))
    return logger
    
def log_close():
    print("Logging close!")
    logging.shutdown()

def get_job_id(filename):        
    if (filename.find('/') != -1): 
        jobName = filename.split('/')
        JOB_ID = jobName[len(jobName) - 1]
    else:
        JOB_ID = filename
        
    if (JOB_ID.find('.csv') != -1): 
        jobName = JOB_ID.split('.csv')
        JOB_ID = jobName[0]
        
    print("JOB_ID=" + str(JOB_ID))    
    return JOB_ID
    
#get config variables    
def get_config_section():
    global emr_client
    global logger
    # Code section to read configs sent as environment variables from CloudFormation script
    try:
        configs = dict()     
        configs["cluster_info"] = {}
        configs["cluster_info"]["cluster_name"] = os.environ['cluster_name']        
        configs["code_info"] = {}
        configs["code_info"]["coe_dir"] = os.environ['code_dir']
        configs["code_info"]["init_file"] = os.environ['init_file']
        
        # Fetching EMR Cluster ID dynamically based on EMR name
        cluster_name = os.environ['cluster_name']        
        emr_client = create_EMR_client('emr')
        
        clusters = list_EMR_cluster()
        logger.info("List of all active clusters: " + str(clusters))

        if clusters:
            cluster_id = [i for i in clusters['Clusters'] if i['Name'] == cluster_name][0]['Id']
            logger.info("Cluster name is " + cluster_name)
            logger.info("Cluster Id is " + cluster_id)
            configs["cluster_info"]["cluster_id"] = cluster_id
        else:
            configs["cluster_info"]["cluster_id"] = ""
        return configs
    except Exception as e:
        logger.error("Failed while retrieving configurations: " + str(e))
        raise Exception("Failed while retrieving configurations: " + str(e))

#list cluster in AWS account
def list_EMR_cluster():
    global emr_client
    try: 
        clusters = emr_client.list_clusters(ClusterStates=['RUNNING','WAITING'])
        logger.info("Got the cluster list successfully!")
    except Exception as e:    
        logger.error("Could not get cluster list on AWS account!" + str(e))
        raise Exception("Could not get cluster list on AWS account!" + str(e))
    return clusters
        

#create boto3 service client
def create_EMR_client(service):
    global logger
    try:  
        client = boto3.client(service)
        logger.info(service + " connection made successfully!")
    except Exception as e:    
        logger.error(service + " connection was not created successfully! " + str(e))
        raise Exception(service + " connection was not created successfully! " + str(e))
    return client

#submit job to givenn cluster        
def submit_job(client,step_args,cluster_id,JOB_ID):        
    global logger
    step = {
                'Name': "JOB: " + str(JOB_ID),
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 's3n://elasticmapreduce/libs/script-runner/script-runner.jar',
                    'Args': step_args
                }
            }
    try:    
        action = client.add_job_flow_steps(JobFlowId=cluster_id, Steps=[step])
        logger.info("Lambda triggered the job on EMR with job id " + JOB_ID )         
        logger.info(action)
    except Exception as e:
        logger.error("Could not trigger the job on EMR with job id " + JOB_ID + " ! " + str(e))    
        raise Exception("Could not trigger the job on EMR with job id " + JOB_ID + " ! " + str(e))
    return action