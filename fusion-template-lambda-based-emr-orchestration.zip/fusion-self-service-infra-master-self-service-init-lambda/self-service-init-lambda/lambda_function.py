import logging
from datetime import date
import helper_lib as utill
import boto3
import os

def lambda_handler(event, context):
    try:
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        filename = event['Records'][0]['s3']['object']['key']
        #get the Job Id
        JOB_ID = utill.get_job_id(filename)

        if JOB_ID != '' and bucket_name != '':
            today = date.today()
            #Setting log config, For each job one log file get generates as [current_date_filename]
            logfile = str(today) + "_" + JOB_ID + ".log"
            #initialize logging
            logger = utill.init_logging(logfile)
            logger.info("Bucket name = " + bucket_name)

            #Get config variables
            conf = utill.get_config_section()
            if filename != '':
                env = os.environ['snowflake_env'] 
                # spark configuration example
                step_args = ["/usr/bin/spark-submit", conf['code_info']['coe_dir'] + conf['code_info']['init_file'] , JOB_ID, bucket_name, env]
                cluster_id = conf['cluster_info']['cluster_id']
                if cluster_id != '':
                    print("submit job to emr " + cluster_id)
                    emr_client = utill.create_EMR_client('emr')
                    action = utill.submit_job(emr_client,step_args,cluster_id,JOB_ID) #submit job to EMR
                else:
                    print("No active Cluster ID found")
                    logger.info("No active Cluster ID found")
                    raise Exception("No active Cluster ID found")
            else:
                print('Could not fetch file name!')
                logger.info("Could not fetch file name!")
                raise Exception("Could not fetch file name!")

            utill.log_close()
        else:
            print("Could not get job ID!")
            raise Exception("Could not get job ID!")
        print("Added step: %s"%(action))
        return True
    except Exception as e:
        logging.error("Failed during Lambda Function execution: ERROR: " + str(e))
        raise Exception(e)