#!/bin/bash
set -exo pipefail


# Installing Extra Packages
# chmod +x package_install.sh
# ./package_install.sh

# Getting values from valut
echo $data > passwd.txt
ansible-vault decrypt --vault-password-file passwd.txt crypt.yml
user_name=$(yq -r ".name" crypt.yml)
passd=$(yq -r ".password" crypt.yml)
account=$(yq -r ".account" crypt.yml)

## for logging
echo username used $user_name

# exporting values
export output="_output.ipynb"
export inputCSV=".csv"
s3_output_bucket=s3://return-forecasting-dev-501442322082/s/d/r
day=$(date "--date=0 day ago" +"%d")
month=$(date "--date=0 day ago" +"%m")
year=$(date "--date=0 day ago" +"%Y")
currentday=$year$month$day
#Running tms notebook
papermill tms.ipynb tms$output -p snowflake_user $user_name -p snowflake_password $passd -p snowflake_account $account -p facility_name $facility_name

echo "publishing the tms to s3"
aws s3 cp $facility_name'_tms.csv' $s3_output_bucket'/tms-file/'$currentday'/'$facility_name'_tms.csv'
echo "Report published"

## Data Preparation
echo "Data Preparation Started"
papermill $facility_name.ipynb $facility_name$output -p snowflake_user $user_name -p snowflake_password $passd -p snowflake_account $account

echo Data Preparation Completed for the faciltiy $facility_name
echo "archiving ecommerce files"
echo "publishing the output notebook to s3"
aws s3 cp $facility_name$output $s3_output_bucket'/output-notebook/'$currentday'/'$facility_name$output
echo "Report published"

echo "publishing the output CSV to s3"
aws s3 cp $facility_name$inputCSV $s3_output_bucket'/batchinput/'$currentday'/'$facility_name$inputCSV
echo "cvs uploaded"

cd /home
echo '' > $facility_name.csv
echo "publishing the success CSV to s3"
aws s3 cp $facility_name$inputCSV $s3_output_bucket'/input/'$currentday'/'$facility_name$inputCSV
echo "cvs uploaded"

exit 0