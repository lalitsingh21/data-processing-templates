import json
import os
import urllib.parse
import snowflake.connector
from boto3 import client
import datetime
import pandas as pd

def lambda_handler(event, context):
    region = os.environ['REGION']
    env = os.environ['ENVIRONMENT']

    input_bucket = event['Records'][0]['s3']['bucket']['name']
    input_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    s3 = client('s3', region_name=region)

    output_volume_data = '/tmp/output_volume_data' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '.csv'    
    s3.download_file(input_bucket, input_key,output_volume_data )

    file_name = str(input_key).split("/")[-1]
    client_name = str(file_name).split("output_")[-1].split(".csv")[0].replace("_", "-")
    if '-volume' in client_name:
        client_name = client_name.split('-volume')[0]
        print("Client - Facility Name extracted: " + client_name)
        
        df=pd.read_csv(output_volume_data)    
        monitoring_output_volume_file = client_name+'_monitoring_output_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '.csv'  
        monitoring_output_volume_data_location = '/tmp/'+monitoring_output_volume_file

        df.to_csv(monitoring_output_volume_data_location,index=False, header=False)
        snowflake_user= os.environ['snowflake_user']
        snowflake_password= os.environ['snowflake_password']
        snowflake_account= os.environ['snowflake_account']
        conf = snowflake.connector.connect(user=snowflake_user, password=snowflake_password, account=snowflake_account)
        cursor = conf.cursor()
        WAREHOUSE='FUSION_CS_DWH'
        DATABASE="FUSION_FDR_DB"
        SCHEMA="ANALYTICS"
        cursor.execute("USE WAREHOUSE " + WAREHOUSE)
        cursor.execute("USE DATABASE " + DATABASE)
        cursor.execute("USE SCHEMA " + SCHEMA)
        uploadToStageQuery = 'put file://'+monitoring_output_volume_data_location+' @%RVP_OUTPUT_VOLUME_DEV'
        cursor.execute(uploadToStageQuery)
        copyIntoQuery = 'COPY INTO "RVP_OUTPUT_VOLUME_DEV" FROM @"%RVP_OUTPUT_VOLUME_DEV" FILE_FORMAT = "HIVEFORMAT"'
        cursor.execute(copyIntoQuery)
        cursor.close()
        
        print("uploading csv file")
        s3.upload_file(monitoring_output_volume_data_location,input_bucket, "s/d/r/monitoring/"+monitoring_output_volume_file)    
    
        df2=pd.read_csv(output_volume_data)   
        df2=df2[df2['daydiff']>=0]
        df2=df2[['ClientFacility','eta','total_f','total_f_lb','total_f_ub']]
        df2.rename(columns = {'eta':'Delivery Date','total_f':'Estimated Volume','total_f_lb':'Lower Bound','total_f_ub':'Upper Bound'}, inplace = True)
        df2['Estimated Volume']=round(df2['Estimated Volume'].astype(int),-2)
        df2['Lower Bound']=round(df2['Lower Bound'].astype(int),-2)
        df2['Upper Bound']=round(df2['Upper Bound'].astype(int),-2)
        
        reporting_output_volume_file = 'output_'+client_name+'_volume'+ datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '.csv'  
        reporting_output_volume_data_location = '/tmp/'+reporting_output_volume_file
        df2.to_csv(reporting_output_volume_data_location,index=False)
        s3.upload_file(reporting_output_volume_data_location,input_bucket, "s/d/r/reporting/"+reporting_output_volume_file)
        
    return {
        'statusCode': 200,
        'body': json.dumps('processing completed successfulyy!!')
    }